
# User Management System (MERN Stack)

## Features
- Add User
- View Users
- Edit User
- Delete User

## Tech Stack
- React (Frontend)
- Node.js + Express (Backend)
- MongoDB (Database)

---

## Backend Setup

1. cd backend
2. npm install
3. npm start

Server runs on:
http://localhost:5000

---

## Frontend Setup

1. cd frontend
2. npm install
3. npm start

Frontend runs on:
http://localhost:3000

---

## Requirements
- Node.js installed
- MongoDB running locally

---

Project Ready for GitHub Upload 🚀
